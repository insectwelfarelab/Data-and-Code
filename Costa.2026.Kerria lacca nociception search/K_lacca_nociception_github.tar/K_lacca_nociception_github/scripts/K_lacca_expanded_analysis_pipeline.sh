#!/usr/bin/env bash
set -euo pipefail

###############################################################################
# KERRIA LACCA — EXPANDED NOCICEPTION-RELATED GENE ANALYSIS
#
# Targets added after the original Goldberg et al. seven-family screen:
#   1) Straightjacket (stj)
#   2) TRPA5
#   3) Pyrexia (Pyx)
#
# This script is a cleaned, reproducible version of the final workflow used
# in the expanded analysis. It assumes that the original K. lacca project
# already exists and that the original eggNOG annotation file and proteome
# have been retained.
#
# Expected project root:
#   ~/K_lacca_gene_families
#
# Required retained files:
#   data/upload/K_lacca_GCA_045014175.1_proteins.faa
#   results/eggnog_v5_full/K_lacca_GCA_045014175_1.emapper.annotations
#   data/K_lacca_GCA_045014175.1/.../genomic.gff
#
# Conda environments used:
#   eggnog_v5   -> Python/Biopython
#   blast_tools -> BLASTP, TBLASTN, makeblastdb
#   phylo_tools -> MAFFT, IQ-TREE
#
# Additional system tools:
#   curl, awk, grep, sed, unzip, antiword
#
# Final expanded-screen interpretation from this workflow:
#   Straightjacket: XKL59236.1, 1 strong full-length candidate
#   TRPA5:         0 convincing orthologs detected
#   Pyrexia:       0 convincing orthologs detected
#
# Important:
# "0 detected" means no convincing ortholog was found in the current assembly
# and annotation. It does NOT mean definitive species-wide absence.
###############################################################################

PROJECT="${HOME}/K_lacca_gene_families"
cd "${PROJECT}"

# Make conda available in non-interactive shells.
source "${HOME}/miniforge3/etc/profile.d/conda.sh"

PROTEOME="data/upload/K_lacca_GCA_045014175.1_proteins.faa"
ANN="results/eggnog_v5_full/K_lacca_GCA_045014175_1.emapper.annotations"

EXP="results/expanded_targets"
REF="data/references/expanded_targets"

mkdir -p "${EXP}/Straightjacket" "${EXP}/TRPA5" "${EXP}/Pyrexia"
mkdir -p "${REF}" "${REF}/Pyx15" "${REF}/Wtrw15"
mkdir -p data/genome_validation/blastdb

# Locate retained GFF.
GFF="$(find data/K_lacca_GCA_045014175.1 -type f -name "genomic.gff" | head -1)"
if [[ -z "${GFF}" ]]; then
    echo "ERROR: genomic.gff not found."
    exit 1
fi

echo "Proteome: ${PROTEOME}"
echo "Annotations: ${ANN}"
echo "GFF: ${GFF}"

###############################################################################
# 1. INITIAL ANNOTATION SCREEN FOR THE THREE EXPANDED TARGETS
###############################################################################

grep -Ei \
'TRPA5|Pyrexia|TRPA2|straightjacket|CACNA2D|alpha.?2.?delta' \
"${ANN}" \
> "${EXP}/new_targets_annotation_search.tsv" || true

###############################################################################
# 2. STRAIGHTJACKET (stj)
###############################################################################

echo "=== Straightjacket analysis ==="

# Identify alpha2delta-family candidates using orthogroup/domain/name evidence.
awk -F'\t' '
$5 ~ /KOG2353/ || $21 ~ /VGCC_alpha2/ || $9 ~ /CACNA2D/ {
    print $1,$2,$3,$4,$5,$8,$9,$21
}' OFS='\t' "${ANN}" \
> "${EXP}/Straightjacket/K_lacca_alpha2delta_candidates.tsv"

# Extract candidate proteins.
conda activate eggnog_v5

python - <<'PY'
from Bio import SeqIO

proteome = "data/upload/K_lacca_GCA_045014175.1_proteins.faa"
tsv = "results/expanded_targets/Straightjacket/K_lacca_alpha2delta_candidates.tsv"
out = "results/expanded_targets/Straightjacket/K_lacca_alpha2delta_candidates.faa"

wanted = set()
with open(tsv) as fh:
    for line in fh:
        if line.strip():
            wanted.add(line.split("\t")[0])

records = [r for r in SeqIO.parse(proteome, "fasta") if r.id in wanted]
SeqIO.write(records, out, "fasta")

print("Straightjacket alpha2delta candidates extracted:", len(records))
for r in records:
    print(r.id, len(r.seq))
PY

conda deactivate
conda activate blast_tools

# D. melanogaster Straightjacket reference.
curl -fL --retry 3 \
"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=protein&id=NP_610902.1&rettype=fasta&retmode=text" \
-o "${REF}/Dmel_stj_NP_610902.1.faa"

# D. melanogaster alpha2delta paralog: Stolid.
curl -fL --retry 3 \
"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=protein&id=NP_001285963.1&rettype=fasta&retmode=text" \
-o "${REF}/Dmel_stolid_NP_001285963.1.faa"

# Additional Drosophila alpha2delta comparator.
curl -fL --retry 3 \
"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=protein&id=NP_611469.1&rettype=fasta&retmode=text" \
-o "${REF}/Dmel_CG16868_NP_611469.1.faa"

cat \
"${REF}/Dmel_stj_NP_610902.1.faa" \
"${REF}/Dmel_stolid_NP_001285963.1.faa" \
"${REF}/Dmel_CG16868_NP_611469.1.faa" \
> "${REF}/Dmel_alpha2delta_refs.faa"

blastp \
-query "${REF}/Dmel_alpha2delta_refs.faa" \
-subject "${EXP}/Straightjacket/K_lacca_alpha2delta_candidates.faa" \
-evalue 1e-5 \
-max_hsps 1 \
-outfmt "6 qseqid sseqid pident length qlen slen qcovs evalue bitscore" \
> "${EXP}/Straightjacket/Dmel_alpha2delta_vs_Klacca.tsv"

# Final Straightjacket summary based on the validated result.
cat > "${EXP}/Straightjacket/stj_summary.tsv" <<'EOF'
Target	Candidate	Length_aa	Dmel_stj_identity	Dmel_stj_coverage	Evalue	Interpretation
Straightjacket	XKL59236.1	1201	35.0	95	0.0	Strong_full-length_candidate
Straightjacket	XKL59237.1	338	partial	12	2.22e-24	Partial_truncated_alpha2delta-like
EOF

###############################################################################
# 3. TRPA5
###############################################################################

echo "=== TRPA5 analysis ==="

# Broad K. lacca TRP-like candidate screen: Ankyrin + Ion_trans.
awk -F'\t' '
$21 ~ /Ion_trans/ && $21 ~ /Ank/ {
    print $1,$2,$3,$4,$5,$8,$9,$21
}' OFS='\t' "${ANN}" \
> "${EXP}/TRPA5/K_lacca_TRPA_like_candidates.tsv"

cut -f1 "${EXP}/TRPA5/K_lacca_TRPA_like_candidates.tsv" \
> "${EXP}/TRPA5/K_lacca_TRPA12_ids.txt"

# Download the R. prolixus sensory-gene supplementary dataset used to obtain
# curated TRPA5/TRPA1/WTRW/PAIN coding sequences.
curl -fL --retry 3 \
'https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fsrep40049/MediaObjects/41598_2017_BFsrep40049_MOESM270_ESM.doc' \
-o "${REF}/Rpro_sensory_genes_SuppDataset1.doc"

antiword \
"${REF}/Rpro_sensory_genes_SuppDataset1.doc" \
> "${REF}/Rpro_sensory_genes_SuppDataset1.txt"

# Extract the seven curated R. prolixus TRPA-related CDS blocks.
awk '
/^>PAIN-FX$/ ||
/^>TRPA1_ISOFORM_A-FX$/ ||
/^>TRPA1_ISOFORM_B-FX$/ ||
/^>WTRW$/ ||
/^>TRPA5A$/ ||
/^>TRPA5B$/ ||
/^>TRPA5C$/ {
    keep=1
    print
    next
}
/^>/ {keep=0}
keep
' "${REF}/Rpro_sensory_genes_SuppDataset1.txt" \
> "${REF}/Rpro_TRPA_reference_CDS.fasta"

# Translate the CDS sequences to proteins.
conda deactivate
conda activate eggnog_v5

python - <<'PY'
from Bio import SeqIO
from Bio.Seq import Seq

inp = "data/references/expanded_targets/Rpro_TRPA_reference_CDS.fasta"
out = "data/references/expanded_targets/Rpro_TRPA_reference_proteins.faa"

with open(out, "w") as handle:
    for rec in SeqIO.parse(inp, "fasta"):
        seq = str(rec.seq).replace(" ", "").replace("\n", "")
        protein = Seq(seq).translate(to_stop=True)
        handle.write(f">{rec.id}\n{protein}\n")

print("R. prolixus translated TRPA reference proteins:")
for rec in SeqIO.parse(out, "fasta"):
    print(rec.id, len(rec.seq))
PY

# Extract the three TRPA5 proteins.
python - <<'PY'
from Bio import SeqIO

inp = "data/references/expanded_targets/Rpro_TRPA_reference_proteins.faa"
out = "data/references/expanded_targets/Rpro_TRPA5ABC_proteins.faa"
wanted = {"TRPA5A", "TRPA5B", "TRPA5C"}

records = [r for r in SeqIO.parse(inp, "fasta") if r.id in wanted]
SeqIO.write(records, out, "fasta")
print("TRPA5 references extracted:", len(records))
PY

# Extract all 12 K. lacca Ank + Ion_trans candidate proteins.
python - <<'PY'
from Bio import SeqIO

ids_file = "results/expanded_targets/TRPA5/K_lacca_TRPA12_ids.txt"
proteome = "data/upload/K_lacca_GCA_045014175.1_proteins.faa"
out = "results/expanded_targets/TRPA5/K_lacca_TRPA12_candidates.faa"

with open(ids_file) as fh:
    wanted = {x.strip() for x in fh if x.strip()}

records = [r for r in SeqIO.parse(proteome, "fasta") if r.id in wanted]
SeqIO.write(records, out, "fasta")
print("Requested:", len(wanted), "Extracted:", len(records))
PY

conda deactivate
conda activate blast_tools

# Whole-proteome BLASTP with the three R. prolixus TRPA5 proteins.
blastp \
-query "${REF}/Rpro_TRPA5ABC_proteins.faa" \
-subject "${PROTEOME}" \
-evalue 1e-5 \
-max_target_seqs 20 \
-max_hsps 1 \
-outfmt "6 qseqid sseqid pident length qlen slen qcovs evalue bitscore" \
> "${EXP}/TRPA5/Rpro_TRPA5_vs_Klacca_proteome_bestHSP.tsv"

# Expanded TRPA phylogeny: seven R. prolixus refs + 12 K. lacca candidates.
cat \
"${REF}/Rpro_TRPA_reference_proteins.faa" \
"${EXP}/TRPA5/K_lacca_TRPA12_candidates.faa" \
> "${EXP}/TRPA5/TRPA19_phylogeny_input.faa"

conda deactivate
conda activate phylo_tools

mafft --auto \
"${EXP}/TRPA5/TRPA19_phylogeny_input.faa" \
> "${EXP}/TRPA5/TRPA19_phylogeny_aligned.faa"

iqtree \
-s "${EXP}/TRPA5/TRPA19_phylogeny_aligned.faa" \
-m MFP \
-B 1000 \
-alrt 1000 \
-T AUTO \
-pre "${EXP}/TRPA5/TRPA19_phylogeny"

###############################################################################
# 4. GENOME DOWNLOAD / BLAST DATABASE
#    Used by both TRPA5 and Pyrexia validation.
###############################################################################

echo "=== Genome-level validation setup ==="

conda deactivate

mkdir -p data/genome_validation

# Use project-local datasets if present; otherwise use datasets from PATH.
if [[ -x "./datasets" ]]; then
    DATASETS_CMD="./datasets"
elif command -v datasets >/dev/null 2>&1; then
    DATASETS_CMD="datasets"
else
    echo "ERROR: NCBI datasets executable not found."
    exit 1
fi

"${DATASETS_CMD}" download genome accession GCA_045014175.1 \
--include genome \
--filename data/genome_validation/K_lacca_genome.zip

unzip -o \
data/genome_validation/K_lacca_genome.zip \
-d data/genome_validation/K_lacca_genome

GENOME="$(find data/genome_validation/K_lacca_genome -type f -name "*.fna" | head -1)"
if [[ -z "${GENOME}" ]]; then
    echo "ERROR: genome FASTA not found after download."
    exit 1
fi

echo "Genome FASTA: ${GENOME}"

conda activate blast_tools

makeblastdb \
-in "${GENOME}" \
-dbtype nucl \
-out data/genome_validation/blastdb/K_lacca_genome \
-parse_seqids

###############################################################################
# 5. TRPA5 GENOME-LEVEL TBLASTN
###############################################################################

tblastn \
-query "${REF}/Rpro_TRPA5ABC_proteins.faa" \
-db data/genome_validation/blastdb/K_lacca_genome \
-evalue 1e-5 \
-max_target_seqs 50 \
-num_threads 4 \
-outfmt "6 qseqid sseqid pident length qlen qstart qend sstart send evalue bitscore" \
> "${EXP}/TRPA5/Rpro_TRPA5_vs_Klacca_genome_tblastn.tsv"

# Inspect the major TRPA5-like genomic loci against the GFF.
awk -F'\t' '
($1=="CP138446.1" && $4<=21161000 && $5>=21157000) ||
($1=="CP138446.1" && $4<=10324000 && $5>=10319000) ||
($1=="CP138450.1" && $4<=3336200 && $5>=3334200) ||
($1=="CP138445.1" && $4<=15211000 && $5>=15209000) ||
($1=="CP138449.1" && $4<=18868000 && $5>=18865000) {
    print
}' "${GFF}" \
> "${EXP}/TRPA5/TRPA5_major_loci_GFF.tsv"

# Final interpretation from the validated workflow:
#   - strongest CP138446.1 loci correspond to XKL62473.1 and XKL62048.1
#     (Waterwitch-like)
#   - CP138450.1 corresponds to XKL66442.1 (Painless)
#   - additional short hits correspond to ankyrin-repeat proteins without
#     complete TRP architecture
#   - no additional convincing TRPA5 locus detected

###############################################################################
# 6. PYREXIA (Pyx): CURATED LIENARD ET AL. 2024 REFERENCE SET
###############################################################################

echo "=== Pyrexia analysis ==="

# Explicit eggNOG/name search.
awk -F'\t' '
tolower($8) ~ /pyrexia|trpa2/ ||
tolower($9) ~ /^(pyx|pyrexia|trpa2)$/ {
    print $1,$2,$3,$4,$5,$8,$9,$21
}' OFS='\t' "${ANN}" \
> "${EXP}/Pyrexia/K_lacca_pyrexia_annotation_search.tsv"

# Download Lienard et al. 2024 Table S1 from the publisher.
curl -fL --retry 3 \
"https://ars.els-cdn.com/content/image/1-s2.0-S2589004224007636-mmc2.xlsx" \
-o "${REF}/Lienard2024_TableS1_TRPA.xlsx"

# Extract shared strings for audit/documentation.
unzip -p \
"${REF}/Lienard2024_TableS1_TRPA.xlsx" \
xl/sharedStrings.xml \
| sed 's/<[^>]*>/\n/g' \
| sed '/^[[:space:]]*$/d' \
> "${EXP}/Pyrexia/Lienard2024_TableS1_strings.txt"

# Fifteen Pyx accessions curated directly from Lienard et al. Table S1.
cat > "${REF}/Lienard2024_Pyx15_accessions.txt" <<'EOF'
XP_972539.2
XP_019768878.1
XP_031337505.1
XP_018322447.1
XP_023313055.1
XP_019880269.1
XP_022902304.1
NP_612015.1
XP_011182444.1
XP_004533435.1
XP_005178657.1
XP_023304611.1
XP_001600001.1
XP_026735244.1
XP_026274445.1
EOF

# Fifteen taxonomically matched Wtrw accessions from the same Table S1.
cat > "${REF}/Lienard2024_Wtrw15_accessions.txt" <<'EOF'
XP_966629.1
XP_019767304.1
XP_031347387.1
XP_018334781.1
XP_023310065.1
XP_019870200.1
XP_022911382.1
NP_731193.1
XP_011184840.1
XP_012158622.1
XP_005183123.1
XP_023300125.1
XP_003427362.1
XP_026735810.1
XP_026273628.1
EOF

# Download all 15 Pyx proteins.
while read -r acc; do
    echo "Downloading Pyx ${acc}"
    curl -fL --retry 3 \
    "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=protein&id=${acc}&rettype=fasta&retmode=text" \
    -o "${REF}/Pyx15/${acc}.faa"
done < "${REF}/Lienard2024_Pyx15_accessions.txt"

# Download all 15 matched Wtrw proteins.
while read -r acc; do
    echo "Downloading Wtrw ${acc}"
    curl -fL --retry 3 \
    "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=protein&id=${acc}&rettype=fasta&retmode=text" \
    -o "${REF}/Wtrw15/${acc}.faa"
done < "${REF}/Lienard2024_Wtrw15_accessions.txt"

cat "${REF}"/Pyx15/*.faa \
> "${REF}/Lienard2024_Pyx15.faa"

cat "${REF}"/Wtrw15/*.faa \
> "${REF}/Lienard2024_Wtrw15.faa"

echo "Pyx count:"
grep -c '^>' "${REF}/Lienard2024_Pyx15.faa"

echo "Wtrw count:"
grep -c '^>' "${REF}/Lienard2024_Wtrw15.faa"

# Whole-proteome BLASTP using all 15 curated Pyx references.
blastp \
-query "${REF}/Lienard2024_Pyx15.faa" \
-subject "${PROTEOME}" \
-evalue 1e-5 \
-max_target_seqs 20 \
-max_hsps 1 \
-outfmt "6 qseqid sseqid pident length qlen slen qcovs evalue bitscore" \
> "${EXP}/Pyrexia/Pyrexia_Pyx15_vs_Klacca_proteome.tsv"

# Balanced 49-protein phylogeny:
#   15 Pyx
#   15 matched Wtrw
#   7 curated R. prolixus TRPA references
#   12 K. lacca TRP-like candidates
cat \
"${REF}/Lienard2024_Pyx15.faa" \
"${REF}/Lienard2024_Wtrw15.faa" \
"${REF}/Rpro_TRPA_reference_proteins.faa" \
"${EXP}/TRPA5/K_lacca_TRPA12_candidates.faa" \
> "${EXP}/Pyrexia/Pyx_Wtrw_TRPA49_phylogeny_input.faa"

conda deactivate
conda activate phylo_tools

mafft --auto \
"${EXP}/Pyrexia/Pyx_Wtrw_TRPA49_phylogeny_input.faa" \
> "${EXP}/Pyrexia/Pyx_Wtrw_TRPA49_phylogeny_aligned.faa"

iqtree \
-s "${EXP}/Pyrexia/Pyx_Wtrw_TRPA49_phylogeny_aligned.faa" \
-m MFP \
-B 1000 \
-alrt 1000 \
-T AUTO \
-pre "${EXP}/Pyrexia/Pyx_Wtrw_TRPA49_phylogeny"

# Key validated local topology:
#   XKL62048.1 + XKL62473.1: SH-aLRT/UFBoot = 98.1/100
#   (XKL62048.1 + XKL62473.1) + R. prolixus WTRW: 100/100
# Thus both are interpreted as Waterwitch-like, not Pyrexia.
#
# The expanded alignment was highly gappy and showed composition
# heterogeneity, so deep inter-subfamily relationships should be interpreted
# conservatively. Final assignments rely on concordant local topology plus
# annotation/domain and genomic evidence.

###############################################################################
# 7. PYREXIA GENOME-LEVEL TBLASTN
###############################################################################

conda deactivate
conda activate blast_tools

tblastn \
-query "${REF}/Lienard2024_Pyx15.faa" \
-db data/genome_validation/blastdb/K_lacca_genome \
-evalue 1e-5 \
-max_target_seqs 50 \
-num_threads 4 \
-outfmt "6 qseqid sseqid pident length qlen qstart qend sstart send evalue bitscore" \
> "${EXP}/Pyrexia/Lienard2024_Pyx15_vs_Klacca_genome_tblastn.tsv"

# Retain strong genome hits for systematic locus validation.
awk '$11 >= 100 {
    print $1,$2,$3,$4,$6,$7,$8,$9,$10,$11
}' OFS='\t' \
"${EXP}/Pyrexia/Lienard2024_Pyx15_vs_Klacca_genome_tblastn.tsv" \
> "${EXP}/Pyrexia/Pyx15_genome_strong_hits.tsv"

# Count strong hits by chromosome.
cut -f2 "${EXP}/Pyrexia/Pyx15_genome_strong_hits.tsv" \
| sort \
| uniq -c \
> "${EXP}/Pyrexia/Pyx15_genome_strong_hits_by_chromosome.txt"

# Verify that all strong CP138446.1 hits fall into the two known Wtrw loci.
awk '
$2=="gb|CP138446.1|" {
    mid=($7+$8)/2

    if (mid>=10300000 && mid<=10330000)
        locus1++
    else if (mid>=21150000 && mid<=21170000)
        locus2++
    else {
        other++
        print "OTHER:", $0
    }
}
END {
    print "XKL62048_locus:", locus1+0
    print "XKL62473_locus:", locus2+0
    print "OTHER_loci:", other+0
}' \
"${EXP}/Pyrexia/Pyx15_genome_strong_hits.tsv" \
> "${EXP}/Pyrexia/Pyx15_CP138446_locus_check.txt"

# Validated result obtained in this analysis:
#   XKL62048_locus: 16
#   XKL62473_locus: 16
#   OTHER_loci: 0
#
# All 15 strong hits on CP138450.1 map to the XKL66442.1 Painless locus.
# Therefore no additional convincing Pyrexia-like locus was identified.

###############################################################################
# 8. FINAL EXPANDED ANALYSIS SUMMARY
###############################################################################

cat > "${EXP}/K_lacca_expanded_target_summary.tsv" <<'EOF'
Target	Candidate	Length_aa	Detected_copies	Interpretation
Straightjacket	XKL59236.1	1201	1	Strong_full-length_candidate
TRPA5	-	-	0	No_convincing_ortholog_detected
Pyrexia	-	-	0	No_convincing_ortholog_detected
EOF

echo
echo "==============================================================="
echo "Expanded analysis completed."
echo "Final summary:"
cat "${EXP}/K_lacca_expanded_target_summary.tsv"
echo "==============================================================="
echo
echo "Interpret 0 as 'not detected in the current assembly/annotation',"
echo "not as definitive species-wide absence."
