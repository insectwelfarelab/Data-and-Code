# Final summary results

Expected files:

- `D_coccus_final_target_loci.tsv`
- `K_lacca_vs_D_coccus_target_comparison.tsv`
- final QC/checksum logs

`D_coccus_final_target_loci.tsv` is the primary locus-level output for downstream reuse.
