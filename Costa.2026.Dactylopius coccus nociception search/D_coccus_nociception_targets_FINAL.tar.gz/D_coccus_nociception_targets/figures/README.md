# Figures

Expected final report figures copied by the staging script:

- `Klacca_vs_Dcoccus_target_repertoire_FINAL.png/.pdf`
- `Dcoccus_target_chromosome_map_FINAL.png/.pdf`
- `TRPA_full_clean.png/.pdf`
- `TRPA_focused.png/.pdf`
- `ppk_final.png/.pdf`
- `alpha2delta_final.png/.pdf`

The *K. lacca* repertoire comparison is descriptive context only and should not be used to infer lineage-specific Pyrexia expansion/contraction.
