# GitHub release checklist

- [ ] Run `scripts/prepare_github_release.sh` from the completed WSL project.
- [ ] Review the staged repository tree before `git add`.
- [ ] Confirm `D_coccus_final_target_loci.tsv` is present.
- [ ] Confirm the final comparison table is present if it will be public.
- [ ] Confirm final Figure 1, chromosome map, TRPA tree, ppk tree, and alpha2delta tree are present.
- [ ] Confirm the compact final workflow RMarkdown is present.
- [ ] Confirm the final report RMarkdown is present only if it is intended for public release.
- [ ] Confirm no genome FASTA, BLAST database, BUSCO/eggNOG database, Conda environment, credentials, or tokens are staged.
- [ ] Add the GitHub repository URL to `CITATION.cff` after the remote repository is created.
- [ ] Choose and add a laboratory/project-approved LICENSE.
- [ ] Confirm authors/contributors.
- [ ] Run `git status` and inspect every staged file.
- [ ] Recommended first release tag after QC: `v1.0.0`.
