from pathlib import Path
import csv

project = Path.home() / "D_coccus_gene_families"
outdir = project / "results/final_summary"
outdir.mkdir(parents=True, exist_ok=True)

rows = [
    {
        "Target": "Painless",
        "Locus_ID": "Dcoc_Painless_1",
        "Chromosome": "Chr3",
        "Accession": "OZ346540.1",
        "Strand": "+",
        "Start": 7396149,
        "End": 7399007,
        "Classification": "Painless",
        "Status": "apparently intact",
        "Counted_in_target": "yes",
        "Key_evidence": "5/5 references converge; clean near/full-length Miniprot models; no frameshift/stop in all five models"
    },
    {
        "Target": "NompC",
        "Locus_ID": "Dcoc_NompC_1",
        "Chromosome": "Chr1",
        "Accession": "OZ346538.1",
        "Strand": "+",
        "Start": 46282729,
        "End": 46305514,
        "Classification": "NompC/TRPN",
        "Status": "apparently intact",
        "Counted_in_target": "yes",
        "Key_evidence": "5/5 references converge; Planococcus model 1-1706 aa, 89.2% identity, no frameshift/stop; four independent clean models"
    },
    {
        "Target": "TRPM",
        "Locus_ID": "Dcoc_TRPM_1",
        "Chromosome": "Chr1",
        "Accession": "OZ346538.1",
        "Strand": "-",
        "Start": 37603483,
        "End": 37649177,
        "Classification": "TRPM",
        "Status": "apparently intact",
        "Counted_in_target": "yes",
        "Key_evidence": "5/5 references converge; long Bemisia model 54-1617 aa; no frameshift/stop"
    },
    {
        "Target": "Piezo",
        "Locus_ID": "Dcoc_Piezo_1",
        "Chromosome": "Chr7",
        "Accession": "OZ346544.1",
        "Strand": "+",
        "Start": 32290668,
        "End": 32335598,
        "Classification": "canonical Piezo",
        "Status": "apparently intact",
        "Counted_in_target": "yes",
        "Key_evidence": "Kerria canonical Piezo 23-2496 aa at 72.9% identity; Planococcus canonical 23-2503 aa at 70.6%; both clean"
    },
    {
        "Target": "Piezo",
        "Locus_ID": "Dcoc_Piezo_2",
        "Chromosome": "Chr5",
        "Accession": "OZ346542.1",
        "Strand": "+",
        "Start": 14896587,
        "End": 14926530,
        "Classification": "divergent Piezo-like paralog",
        "Status": "apparently intact",
        "Counted_in_target": "yes",
        "Key_evidence": "Kerria XKL69451.1 model 23-1587 aa, 52.9% identity, no frameshift/stop; Planococcus Piezo-like maps essentially full length"
    },
    {
        "Target": "ppk/rpk/ppk26",
        "Locus_ID": "Dcoc_ppk41X6F_upstream",
        "Chromosome": "Chr6",
        "Accession": "OZ346543.1",
        "Strand": "+",
        "Start": 30609480,
        "End": 30619142,
        "Classification": "ppk/41X6F-like target-related",
        "Status": "apparently intact",
        "Counted_in_target": "yes",
        "Key_evidence": "clean XKL60324.1/XKL60325.1 models; sister to downstream locus; exact ppk/rpk/ppk26 one-to-one orthology unresolved"
    },
    {
        "Target": "ppk/rpk/ppk26",
        "Locus_ID": "Dcoc_ppk41X6F_downstream",
        "Chromosome": "Chr6",
        "Accession": "OZ346543.1",
        "Strand": "+",
        "Start": 30621872,
        "End": 30628884,
        "Classification": "ppk/41X6F-like target-related",
        "Status": "apparently intact",
        "Counted_in_target": "yes",
        "Key_evidence": "XKL60324.1 full-length 1-449 aa clean model; sister to upstream locus; exact ppk/rpk/ppk26 one-to-one orthology unresolved"
    },
    {
        "Target": "TRPA1",
        "Locus_ID": "Dcoc_TRPA1_1",
        "Chromosome": "Chr6",
        "Accession": "OZ346543.1",
        "Strand": "-",
        "Start": 30915200,
        "End": 30933269,
        "Classification": "TRPA1",
        "Status": "apparently intact",
        "Counted_in_target": "yes",
        "Key_evidence": "5/5 references converge; all models have 0 frameshift and 0 stop; Kerria/Planococcus identity 84-86%"
    },
    {
        "Target": "TRPA5",
        "Locus_ID": "Dcoc_TRPA5_chr3",
        "Chromosome": "Chr3",
        "Accession": "OZ346540.1",
        "Strand": "-",
        "Start": 28704715,
        "End": 28709568,
        "Classification": "TRPA5 orthologous locus",
        "Status": "disrupted; intact coding sequence not confirmed",
        "Counted_in_target": "qualified",
        "Key_evidence": "TRPA5 phylogenetic clade 100/100; Miniprot predicts 3 frameshifts + 1 internal stop; affected interval contains no N bases"
    },
    {
        "Target": "Pyrexia",
        "Locus_ID": "Dcoc_Pyx_A",
        "Chromosome": "Chr1",
        "Accession": "OZ346538.1",
        "Strand": "-",
        "Start": 27146889,
        "End": 27149687,
        "Classification": "Pyrexia-lineage",
        "Status": "apparently intact",
        "Counted_in_target": "yes",
        "Key_evidence": "934-aa clean reconstructed protein; A/B sister pair 100/100; Pyrexia-lineage clade supported"
    },
    {
        "Target": "Pyrexia",
        "Locus_ID": "Dcoc_Pyx_B",
        "Chromosome": "Chr6",
        "Accession": "OZ346543.1",
        "Strand": "+",
        "Start": 96561,
        "End": 99350,
        "Classification": "Pyrexia-lineage",
        "Status": "apparently intact",
        "Counted_in_target": "yes",
        "Key_evidence": "922-aa clean reconstructed protein; 95.77% protein identity to A; inverted segmental duplication; A/B sister pair 100/100"
    },
    {
        "Target": "Pyrexia",
        "Locus_ID": "Dcoc_Pyx_C",
        "Chromosome": "Chr3",
        "Accession": "OZ346540.1",
        "Strand": "+",
        "Start": 38871389,
        "End": 38873986,
        "Classification": "Pyrexia-lineage divergent paralog",
        "Status": "apparently intact",
        "Counted_in_target": "yes",
        "Key_evidence": "811-aa clean reconstructed protein; sister to Kerria XKL62048.1 at 100/100; ~44-46% identity to A/B"
    },
    {
        "Target": "Straightjacket",
        "Locus_ID": "Dcoc_Straightjacket_1",
        "Chromosome": "Chr8",
        "Accession": "OZ346545.1",
        "Strand": "+",
        "Start": 10631984,
        "End": 10652284,
        "Classification": "Straightjacket-like",
        "Status": "apparently intact",
        "Counted_in_target": "yes",
        "Key_evidence": "Kerria XKL59236.1 full-length 1-1201 aa clean model, 56.4% identity; Planococcus stj references near full length"
    },
    {
        "Target": "Straightjacket",
        "Locus_ID": "Dcoc_stolid_like",
        "Chromosome": "Chr5",
        "Accession": "OZ346542.1",
        "Strand": "-",
        "Start": 40084627,
        "End": 40122514,
        "Classification": "stolid-like alpha2delta paralog",
        "Status": "apparently intact",
        "Counted_in_target": "no",
        "Key_evidence": "Drosophila stolid NP_001285963.1 1-1258 aa clean model; phylogenetic sister relationship 90.5/71"
    },
]

outfile = outdir / "D_coccus_final_target_loci.tsv"

fields = [
    "Target",
    "Locus_ID",
    "Chromosome",
    "Accession",
    "Strand",
    "Start",
    "End",
    "Classification",
    "Status",
    "Counted_in_target",
    "Key_evidence",
]

with outfile.open("w", newline="") as fh:
    writer = csv.DictWriter(fh, fieldnames=fields, delimiter="\t")
    writer.writeheader()
    writer.writerows(rows)

print(f"Wrote {len(rows)} locus rows:")
print(outfile)
