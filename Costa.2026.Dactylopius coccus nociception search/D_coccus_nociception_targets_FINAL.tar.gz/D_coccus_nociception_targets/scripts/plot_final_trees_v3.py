#!/usr/bin/env python3

from pathlib import Path
import copy
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from Bio import Phylo

PROJECT = Path.home() / "D_coccus_gene_families"
OUTDIR = PROJECT / "results" / "final_tree_figures_v3"
OUTDIR.mkdir(parents=True, exist_ok=True)

TRPA_TREE = PROJECT / "results/genome_search/TRPA_phylogeny_Dcoccus/Pyx_Wtrw_TRPA61_Dcoccus_ml.treefile"
PPK_TREE = PROJECT / "results/genome_search/final_classification_ppk_stj/ppk/ppk_ml.treefile"
A2D_TREE = PROJECT / "results/genome_search/final_classification_ppk_stj/straightjacket/alpha2delta_ml.treefile"

EXACT_LABELS = {
    "Dcoccus_PyxWTRW_A": "D. coccus Pyx-A",
    "Dcoccus_PyxWTRW_B": "D. coccus Pyx-B",
    "Dcoccus_PyxWTRW_C": "D. coccus Pyx-C",
    "Dcoccus_TRPA5_candidate_DISRUPTED": "D. coccus TRPA5 disrupted",

    "Dcoccus_ppk_upstream|best_query_XKL60324.1|AS_634|qcov_0.873|aa_383":
        "D. coccus ppk-like upstream",
    "Dcoccus_ppk_downstream|best_query_XKL60324.1|AS_771|qcov_1.000|aa_454":
        "D. coccus ppk-like downstream",

    "Dcoccus_alpha2delta_1|best_query_XKL59236.1|AS_2596|qcov_1.000|aa_1220":
        "D. coccus Straightjacket-like",
    "Dcoccus_alpha2delta_2|best_query_NP_001285963.1|AS_1727|qcov_0.998|aa_1202":
        "D. coccus stolid-like",

    "XKL59236.1": "K. lacca Straightjacket",
    "XKL60324.1": "K. lacca ppk-like 1",
    "XKL60325.1": "K. lacca ppk-like 2",
    "XKL60332.1": "K. lacca TRPA1",
    "XKL62048.1": "K. lacca Pyx-like 1",
    "XKL62473.1": "K. lacca Pyx-like 2",

    "NP_612015.1": "D. melanogaster Pyrexia",
    "NP_610902.1": "D. melanogaster Straightjacket",
    "NP_001285963.1": "D. melanogaster stolid",
    "NP_611469.1": "D. melanogaster CG16868",

    "FBpp0293856": "D. melanogaster ppk-like FBpp0293856",
    "FBpp0080210": "D. melanogaster ppk-like FBpp0080210",
    "FBpp0305020": "D. melanogaster ppk-like FBpp0305020",

    "7029.ACYPI29894-PA": "A. pisum ppk-like 29894",
    "7029.ACYPI068872-PA": "A. pisum ppk-like 068872",
    "7029.ACYPI35976-PA": "A. pisum ppk-like 35976",
    "XP_008180504.1": "A. pisum Straightjacket",
    "XP_016657902.1": "A. pisum Pyrexia",
    "XP_029342926.1": "A. pisum TRPA1",

    "XP_018903257.2": "B. tabaci ppk-like 1",
    "XP_018903260.2": "B. tabaci ppk-like 2",
    "XP_018912170.2": "B. tabaci Straightjacket",
    "XP_072154215.1": "B. tabaci TRPA1",

    "XP_025205608.1": "M. sacchari Pyrexia",

    "WTRW": "R. prolixus WTRW",
    "TRPA5A": "R. prolixus TRPA5-A",
    "TRPA5B": "R. prolixus TRPA5-B",
    "TRPA5C": "R. prolixus TRPA5-C",
    "TRPA1_ISOFORM_A-FX": "R. prolixus TRPA1-A",
    "TRPA1_ISOFORM_B-FX": "R. prolixus TRPA1-B",
}

SUBSTRING_LABELS = [
    ("XP_065212998.1", "P. citri TRPA1"),
    ("XP_065225000.1", "P. citri TRPA5"),
    ("XP_065212443.1", "P. citri Pyx/WTRW-like 443"),
    ("XP_065212444.1", "P. citri Pyx/WTRW-like 444"),
    ("XP_065212445.1", "P. citri Pyx/WTRW-like 445"),
    ("XP_065226234.1", "P. citri Pyx/WTRW-like 226234"),
    ("XP_065203929.1", "P. citri ppk-related"),
    ("XP_065211725.1", "P. citri Straightjacket-1"),
    ("XP_065226481.1", "P. citri Straightjacket-2"),
    ("XP_065211727.1", "P. citri alpha2delta3-like"),
    ("XP_018905356.2", "B. tabaci Pyx/WTRW-like"),
]

SUPPORT_RE = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*/\s*(\d+(?:\.\d+)?)\s*$")

TRPA_FOCUS_PATTERNS = [
    "Dcoccus_PyxWTRW_A",
    "Dcoccus_PyxWTRW_B",
    "Dcoccus_PyxWTRW_C",
    "Dcoccus_TRPA5_candidate_DISRUPTED",
    "XKL60332.1",
    "XP_065212998.1",
    "XP_029342926.1",
    "XP_072154215.1",
    "TRPA1_ISOFORM_A-FX",
    "TRPA1_ISOFORM_B-FX",
    "XP_065225000.1",
    "TRPA5A",
    "TRPA5B",
    "TRPA5C",
    "NP_612015.1",
    "XP_016657902.1",
    "XP_025205608.1",
    "XP_018905356.2",
    "WTRW",
    "XKL62048.1",
    "XKL62473.1",
    "XP_065212443.1",
    "XP_065212444.1",
    "XP_065212445.1",
    "XP_065226234.1",
]

def simplify_terminal_label(label):
    if label is None:
        return ""
    if label in EXACT_LABELS:
        return EXACT_LABELS[label]
    for pattern, replacement in SUBSTRING_LABELS:
        if pattern in label:
            return replacement
    if label.startswith("PPK-like"):
        return "R. prolixus " + label
    return label

def filter_internal_support_labels(tree, threshold=80.0, always_keep=None):
    always_keep = set(always_keep or [])
    for clade in tree.get_nonterminals():
        if not clade.name:
            continue
        raw = str(clade.name).strip()
        m = SUPPORT_RE.match(raw)
        if not m:
            continue
        sh = float(m.group(1))
        uf = float(m.group(2))
        if raw in always_keep:
            clade.name = f"{m.group(1)}/{m.group(2)}"
        elif sh < threshold and uf < threshold:
            clade.name = None
        else:
            clade.name = f"{m.group(1)}/{m.group(2)}"

def terminal_matches_any(label, patterns):
    if label is None:
        return False
    return any(pattern in label for pattern in patterns)

def pruned_copy(tree, keep_patterns):
    t = copy.deepcopy(tree)
    remove = [
        tip for tip in list(t.get_terminals())
        if not terminal_matches_any(tip.name, keep_patterns)
    ]
    for tip in remove:
        try:
            t.prune(tip)
        except ValueError:
            pass
    return t

def rename_terminals(tree):
    for tip in tree.get_terminals():
        tip.name = simplify_terminal_label(tip.name)

def style_axes(ax, title):
    ax.set_title(title, fontsize=13, pad=14)
    ax.set_xlabel("Branch length (substitutions/site)", fontsize=10)
    ax.set_ylabel("")
    ax.set_yticks([])
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)

def emphasize_dcoccus(ax):
    for txt in ax.texts:
        if txt.get_text().strip().startswith("D. coccus"):
            txt.set_fontweight("bold")

def save_tree(tree, prefix, title, tip_font=9, width=13):
    tree.ladderize()
    n = len(tree.get_terminals())
    height = max(5.5, n * 0.34)

    fig = plt.figure(figsize=(width, height))
    ax = fig.add_subplot(1, 1, 1)

    Phylo.draw(tree, axes=ax, do_show=False, show_confidence=False)
    style_axes(ax, title)

    for txt in ax.texts:
        value = txt.get_text().strip()
        if SUPPORT_RE.match(value):
            txt.set_fontsize(max(7, tip_font - 1))
        else:
            txt.set_fontsize(tip_font)

    emphasize_dcoccus(ax)
    plt.tight_layout()

    fig.savefig(OUTDIR / f"{prefix}.png", dpi=300, bbox_inches="tight")
    fig.savefig(OUTDIR / f"{prefix}.pdf", bbox_inches="tight")
    plt.close(fig)

    print(f"Saved: {OUTDIR / (prefix + '.png')}")
    print(f"Saved: {OUTDIR / (prefix + '.pdf')}")

def main():
    trpa_raw = Phylo.read(TRPA_TREE, "newick")

    trpa_full = copy.deepcopy(trpa_raw)
    filter_internal_support_labels(trpa_full, threshold=80)
    rename_terminals(trpa_full)
    save_tree(
        trpa_full,
        "TRPA_full_clean",
        "Unrooted ML TRPA phylogeny: full 61-sequence analysis",
        tip_font=7,
        width=15,
    )

    trpa_focus = pruned_copy(trpa_raw, TRPA_FOCUS_PATTERNS)
    filter_internal_support_labels(trpa_focus, threshold=80)
    rename_terminals(trpa_focus)
    save_tree(
        trpa_focus,
        "TRPA_focused",
        "TRPA5 and Pyrexia/WTRW classification in D. coccus (focused view)",
        tip_font=9,
        width=13,
    )

    ppk = Phylo.read(PPK_TREE, "newick")
    # Keep the biologically important moderate support for the D. coccus
    # upstream/downstream sister pair.
    filter_internal_support_labels(
        ppk,
        threshold=80,
        always_keep={"75.6/79"},
    )
    rename_terminals(ppk)
    save_tree(
        ppk,
        "ppk_final",
        "Unrooted ML ppk/DEG-ENaC phylogeny: D. coccus target-related loci",
        tip_font=9,
        width=13,
    )

    a2d = Phylo.read(A2D_TREE, "newick")
    filter_internal_support_labels(a2d, threshold=80)
    rename_terminals(a2d)
    save_tree(
        a2d,
        "alpha2delta_final",
        "Unrooted ML alpha2delta phylogeny: Straightjacket-like and stolid-like loci",
        tip_font=10,
        width=12,
    )

    print("DONE")

if __name__ == "__main__":
    main()
