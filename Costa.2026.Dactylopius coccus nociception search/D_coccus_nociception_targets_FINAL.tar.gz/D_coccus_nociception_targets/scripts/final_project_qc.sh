#!/usr/bin/env bash
set -u

PROJECT="$HOME/D_coccus_gene_families"
DATE_TAG="2026-09-01"

cd "$PROJECT" || exit 1

mkdir -p logs results/final_summary

LOG="logs/final_project_qc_${DATE_TAG}.txt"
SHA="logs/final_summary_SHA256_${DATE_TAG}.txt"

{
    echo "============================================================"
    echo "Dactylopius coccus gene-family analysis: FINAL PROJECT QC"
    echo "Date tag: ${DATE_TAG}"
    echo "============================================================"
    echo

    echo "[1] Project directory"
    pwd
    echo

    echo "[2] Genome FASTA"
    ls -lh data/D_coccus_genome.fna
    echo
    echo "Genome SHA256:"
    sha256sum data/D_coccus_genome.fna
    echo

    echo "[3] Final summary tables"
    for f in \
        results/final_summary/D_coccus_final_target_loci.tsv \
        results/final_summary/K_lacca_vs_D_coccus_target_comparison.tsv
    do
        echo "------------------------------------------------------------"
        echo "$f"
        ls -lh "$f"
        wc -l "$f"
        head -1 "$f"
    done
    echo

    echo "[4] Final summary row checks"
    LOCUS_LINES=$(wc -l < results/final_summary/D_coccus_final_target_loci.tsv)
    COMP_LINES=$(wc -l < results/final_summary/K_lacca_vs_D_coccus_target_comparison.tsv)

    echo "Locus table total lines:      $LOCUS_LINES"
    echo "Comparison table total lines: $COMP_LINES"

    if [ "$LOCUS_LINES" -eq 15 ]; then
        echo "PASS: locus table = 1 header + 14 locus rows"
    else
        echo "WARNING: expected 15 total lines for locus table"
    fi

    if [ "$COMP_LINES" -eq 11 ]; then
        echo "PASS: comparison table = 1 header + 10 target rows"
    else
        echo "WARNING: expected 11 total lines for comparison table"
    fi
    echo

    echo "[5] Final scripts"
    for f in \
        scripts/build_final_Dcoccus_summary.py \
        scripts/build_target_comparison.py
    do
        if [ -s "$f" ]; then
            echo "PASS: $f"
        else
            echo "WARNING: missing or empty: $f"
        fi
    done
    echo

    echo "[6] Software versions"
    echo "--- BUSCO ---"
    busco --version 2>&1 || true
    echo

    echo "--- BLAST ---"
    tblastn -version 2>&1 | head -2 || true
    echo

    echo "--- Miniprot ---"
    miniprot --version 2>&1 || true
    echo

    echo "--- MAFFT ---"
    if command -v mafft >/dev/null 2>&1; then
        mafft --version 2>&1 | head -2
    elif [ -x "$HOME/miniforge3/envs/phylo_tools/bin/mafft" ]; then
        "$HOME/miniforge3/envs/phylo_tools/bin/mafft" --version 2>&1 | head -2
    else
        echo "MAFFT not found in current PATH"
    fi
    echo

    echo "--- IQ-TREE ---"
    if command -v iqtree >/dev/null 2>&1; then
        iqtree --version 2>&1 | head -5
    elif [ -x "$HOME/miniforge3/envs/phylo_tools/bin/iqtree" ]; then
        "$HOME/miniforge3/envs/phylo_tools/bin/iqtree" --version 2>&1 | head -5
    else
        echo "IQ-TREE not found"
    fi
    echo

    echo "[7] Key final classifications"
    cut -f1,2,8,9,10 results/final_summary/D_coccus_final_target_loci.tsv \
        | column -t -s $'\t'
    echo

    echo "[8] Cross-species comparison"
    cut -f1-3 results/final_summary/K_lacca_vs_D_coccus_target_comparison.tsv \
        | column -t -s $'\t'
    echo

    echo "============================================================"
    echo "FINAL QC COMPLETE"
    echo "============================================================"
} 2>&1 | tee "$LOG"

sha256sum \
    results/final_summary/D_coccus_final_target_loci.tsv \
    results/final_summary/K_lacca_vs_D_coccus_target_comparison.tsv \
    scripts/build_final_Dcoccus_summary.py \
    scripts/build_target_comparison.py \
    > "$SHA"

echo
echo "QC log:"
echo "$PROJECT/$LOG"
echo
echo "Final-summary checksums:"
echo "$PROJECT/$SHA"
