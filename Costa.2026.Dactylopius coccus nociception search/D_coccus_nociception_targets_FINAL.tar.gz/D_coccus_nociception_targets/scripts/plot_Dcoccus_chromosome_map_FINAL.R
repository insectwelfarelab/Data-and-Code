#!/usr/bin/env Rscript

# ============================================================
# Chromosomal distribution of final Dactylopius coccus loci
# Presentation version v2
# ============================================================

needed <- c("ggplot2", "dplyr", "readr", "stringr", "ggrepel")
missing_pkgs <- needed[!vapply(needed, requireNamespace, logical(1), quietly = TRUE)]

if (length(missing_pkgs) > 0) {
  install.packages(missing_pkgs, repos = "https://cloud.r-project.org")
}

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(readr)
  library(stringr)
  library(ggrepel)
})

project_dir <- path.expand("~/D_coccus_gene_families")

input_file <- file.path(
  project_dir,
  "results",
  "final_summary",
  "D_coccus_final_target_loci.tsv"
)

out_dir <- file.path(
  project_dir,
  "results",
  "final_figures"
)

dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

if (!file.exists(input_file)) {
  stop("Input file not found:\n", input_file)
}

loci <- read_tsv(input_file, show_col_types = FALSE)

required_cols <- c(
  "Target", "Locus_ID", "Chromosome",
  "Start", "End", "Status", "Counted_in_target"
)

missing_cols <- setdiff(required_cols, names(loci))

if (length(missing_cols) > 0) {
  stop(
    "Missing expected columns: ",
    paste(missing_cols, collapse = ", ")
  )
}

# Chromosome lengths for GCA_977009245.1.
chromosomes <- tibble::tribble(
  ~Chromosome, ~Length_bp,
  "Chr1", 53690824,
  "Chr2", 53542863,
  "Chr3", 47784591,
  "Chr4", 46180480,
  "Chr5", 43106315,
  "Chr6", 39633058,
  "Chr7", 37830695,
  "Chr8", 37532705
) %>%
  mutate(
    Length_Mb = Length_bp / 1e6,
    Chr_order = factor(
      Chromosome,
      levels = rev(paste0("Chr", 1:8))
    )
  )

loci_plot <- loci %>%
  mutate(
    Position_Mb = ((Start + End) / 2) / 1e6,

    Plot_label = case_when(
      Locus_ID == "Dcoc_Painless_1" ~ "Painless",
      Locus_ID == "Dcoc_NompC_1" ~ "NompC",
      Locus_ID == "Dcoc_TRPM_1" ~ "TRPM",
      Locus_ID == "Dcoc_Piezo_1" ~ "Piezo-1",
      Locus_ID == "Dcoc_Piezo_2" ~ "Piezo-2",
      Locus_ID == "Dcoc_ppk41X6F_upstream" ~ "ppk-like upstream",
      Locus_ID == "Dcoc_ppk41X6F_downstream" ~ "ppk-like downstream",
      Locus_ID == "Dcoc_TRPA1_1" ~ "TRPA1",
      Locus_ID == "Dcoc_TRPA5_chr3" ~ "TRPA5",
      Locus_ID == "Dcoc_Pyx_A" ~ "Pyx-A",
      Locus_ID == "Dcoc_Pyx_B" ~ "Pyx-B",
      Locus_ID == "Dcoc_Pyx_C" ~ "Pyx-C",
      Locus_ID == "Dcoc_Straightjacket_1" ~ "Straightjacket-like",
      Locus_ID == "Dcoc_stolid_like" ~ "stolid-like (not counted)",
      TRUE ~ Locus_ID
    ),

    Display_status = case_when(
      Counted_in_target == "no" ~
        "Additional paralog (not counted)",

      Counted_in_target == "qualified" |
        str_detect(Status, regex("disrupt", ignore_case = TRUE)) ~
        "Disrupted orthologous locus",

      TRUE ~
        "Apparently intact"
    ),

    Chr_order = factor(
      Chromosome,
      levels = rev(paste0("Chr", 1:8))
    ),

    # Explicit nudges for crowded loci.
    nudge_x = case_when(
      Locus_ID == "Dcoc_ppk41X6F_upstream" ~ -6.5,
      Locus_ID == "Dcoc_ppk41X6F_downstream" ~ 7.0,
      Locus_ID == "Dcoc_TRPA1_1" ~ 1.8,
      Locus_ID == "Dcoc_NompC_1" ~ -1.5,
      Locus_ID == "Dcoc_TRPM_1" ~ 1.8,
      TRUE ~ 0
    ),

    nudge_y = case_when(
      Locus_ID == "Dcoc_ppk41X6F_upstream" ~ 0.35,
      Locus_ID == "Dcoc_ppk41X6F_downstream" ~ -0.36,
      Locus_ID == "Dcoc_TRPA1_1" ~ -0.42,
      Locus_ID == "Dcoc_NompC_1" ~ -0.28,
      Locus_ID == "Dcoc_TRPM_1" ~ 0.28,
      TRUE ~ 0
    )
  )

if (nrow(loci_plot) != 14) {
  warning(
    "The final locus table contains ", nrow(loci_plot),
    " rows; expected final project table contains 14."
  )
}

caption_text <- paste0(
  "Positions represent the midpoint of each final locus interval. ",
  "TRPA5 is classified as a disrupted orthologous locus because an intact coding sequence ",
  "was not confirmed. The stolid-like alpha2delta paralog is shown for context ",
  "but is not counted as Straightjacket. Pkd2 is not shown because no genomic ",
  "locus was detected."
)

p <- ggplot() +
  geom_segment(
    data = chromosomes,
    aes(
      x = 0,
      xend = Length_Mb,
      y = Chr_order,
      yend = Chr_order
    ),
    linewidth = 8,
    lineend = "round",
    colour = "grey82"
  ) +

  # One marker shape, with fill indicating status.
  # This ensures the legend preserves the status colors.
  geom_point(
    data = loci_plot,
    aes(
      x = Position_Mb,
      y = Chr_order,
      fill = Display_status
    ),
    shape = 21,
    size = 4.5,
    stroke = 0.9,
    colour = "black"
  ) +

  geom_text_repel(
    data = loci_plot,
    aes(
      x = Position_Mb,
      y = Chr_order,
      label = Plot_label
    ),
    nudge_x = loci_plot$nudge_x,
    nudge_y = loci_plot$nudge_y,
    seed = 123,
    size = 3.55,
    fontface = "bold",
    box.padding = 0.45,
    point.padding = 0.45,
    min.segment.length = 0,
    segment.size = 0.35,
    max.overlaps = Inf,
    force = 1.5
  ) +

  scale_fill_manual(
    values = c(
      "Apparently intact" = "#D9EAD3",
      "Disrupted orthologous locus" = "#F4CCCC",
      "Additional paralog (not counted)" = "#D9D2E9"
    ),
    breaks = c(
      "Apparently intact",
      "Disrupted orthologous locus",
      "Additional paralog (not counted)"
    )
  ) +

  scale_x_continuous(
    limits = c(0, 57),
    breaks = seq(0, 50, 10),
    expand = expansion(mult = c(0.01, 0.02))
  ) +

  labs(
    title = expression(
      "Chromosomal distribution of target loci in " *
        italic("Dactylopius coccus")
    ),
    subtitle = "Final genome-level locus assignments",
    x = "Chromosomal position (Mb)",
    y = NULL,
    fill = "Locus status",
    caption = str_wrap(caption_text, width = 120)
  ) +

  guides(
    fill = guide_legend(
      title.position = "top",
      nrow = 1,
      byrow = TRUE,
      override.aes = list(
        shape = 22,
        size = 5,
        colour = "black"
      )
    )
  ) +

  theme_minimal(base_size = 12.5) +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_line(
      linewidth = 0.35,
      colour = "grey90"
    ),

    axis.text.y = element_text(
      face = "bold",
      size = 11
    ),

    axis.text.x = element_text(
      size = 10.5
    ),

    axis.title.x = element_text(
      face = "bold",
      margin = margin(t = 8)
    ),

    plot.title = element_text(
      face = "bold",
      size = 17,
      hjust = 0.5
    ),

    plot.subtitle = element_text(
      size = 12.5,
      hjust = 0.5,
      margin = margin(b = 14)
    ),

    legend.position = "bottom",
    legend.title = element_text(
      face = "bold",
      size = 11
    ),
    legend.text = element_text(
      size = 10
    ),
    legend.spacing.x = unit(0.4, "cm"),

    plot.caption = element_text(
      size = 9.2,
      hjust = 0,
      lineheight = 1.15,
      margin = margin(t = 14)
    ),

    plot.margin = margin(
      18, 45, 22, 28
    )
  )

png_file <- file.path(
  out_dir,
  "Dcoccus_target_chromosome_map_FINAL.png"
)

pdf_file <- file.path(
  out_dir,
  "Dcoccus_target_chromosome_map_FINAL.pdf"
)

ggsave(
  png_file,
  p,
  width = 12.5,
  height = 8.3,
  units = "in",
  dpi = 300,
  bg = "white"
)

ggsave(
  pdf_file,
  p,
  width = 12.5,
  height = 8.3,
  units = "in",
  bg = "white"
)

message("")
message("DONE")
message("PNG: ", png_file)
message("PDF: ", pdf_file)
message("Locus rows plotted: ", nrow(loci_plot))
message("Expected final locus rows: 14")
