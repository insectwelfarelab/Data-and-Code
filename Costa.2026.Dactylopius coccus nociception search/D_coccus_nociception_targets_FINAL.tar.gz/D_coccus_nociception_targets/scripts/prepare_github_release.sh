#!/usr/bin/env bash
set -euo pipefail

PROJECT="${1:-$HOME/D_coccus_gene_families}"
DEST="${2:-$PROJECT/github_release/D_coccus_nociception_targets}"
TEMPLATE="${3:-$PROJECT/github_template}"

mkdir -p "$DEST"/{scripts,figures,docs,environment,results/final_summary,results/phylogeny}

echo "Project: $PROJECT"
echo "Destination: $DEST"

# Copy the repository template itself first, if available.
if [ -d "$TEMPLATE" ]; then
    cp -a "$TEMPLATE/." "$DEST/"
    echo "Template copied from: $TEMPLATE"
else
    echo "WARNING: template directory not found: $TEMPLATE"
    echo "Final analysis files will still be staged, but README/CITATION/.gitignore must be added separately."
fi

copy_if_exists() {
    src="$1"
    dst="$2"
    if [ -f "$src" ]; then
        cp -p "$src" "$dst"
        echo "COPIED: $src"
    else
        echo "MISSING (skipped): $src"
    fi
}

# Final tables
copy_if_exists "$PROJECT/results/final_summary/D_coccus_final_target_loci.tsv" "$DEST/results/final_summary/"
copy_if_exists "$PROJECT/results/final_summary/K_lacca_vs_D_coccus_target_comparison.tsv" "$DEST/results/final_summary/"

# Final report figures
for f in \
  "$PROJECT/results/final_figures/Klacca_vs_Dcoccus_target_repertoire_FINAL.png" \
  "$PROJECT/results/final_figures/Klacca_vs_Dcoccus_target_repertoire_FINAL.pdf" \
  "$PROJECT/results/final_figures/Dcoccus_target_chromosome_map_FINAL.png" \
  "$PROJECT/results/final_figures/Dcoccus_target_chromosome_map_FINAL.pdf" \
  "$PROJECT/results/final_tree_figures_v3/TRPA_full_clean.png" \
  "$PROJECT/results/final_tree_figures_v3/TRPA_full_clean.pdf" \
  "$PROJECT/results/final_tree_figures_v3/TRPA_focused.png" \
  "$PROJECT/results/final_tree_figures_v3/TRPA_focused.pdf" \
  "$PROJECT/results/final_tree_figures_v3/ppk_final.png" \
  "$PROJECT/results/final_tree_figures_v3/ppk_final.pdf" \
  "$PROJECT/results/final_tree_figures_v3/alpha2delta_final.png" \
  "$PROJECT/results/final_tree_figures_v3/alpha2delta_final.pdf"
do
    copy_if_exists "$f" "$DEST/figures/"
done

# Final tree files
copy_if_exists "$PROJECT/results/genome_search/TRPA_phylogeny_Dcoccus/Pyx_Wtrw_TRPA61_Dcoccus_ml.treefile" "$DEST/results/phylogeny/TRPA_Pyx_Wtrw_Dcoccus.treefile"
copy_if_exists "$PROJECT/results/genome_search/final_classification_ppk_stj/ppk/ppk_ml.treefile" "$DEST/results/phylogeny/ppk_Dcoccus.treefile"
copy_if_exists "$PROJECT/results/genome_search/final_classification_ppk_stj/straightjacket/alpha2delta_ml.treefile" "$DEST/results/phylogeny/alpha2delta_Dcoccus.treefile"

# Final scripts
for f in \
  build_final_Dcoccus_summary.py \
  build_target_comparison.py \
  plot_final_trees_v3.py \
  plot_target_repertoire_comparison_FINAL.R \
  plot_Dcoccus_chromosome_map_FINAL.R \
  final_project_qc.sh
do
    copy_if_exists "$PROJECT/scripts/$f" "$DEST/scripts/"
done

# Final RMarkdown documentation
copy_if_exists "$PROJECT/D_coccus_gene_family_workflow_FINAL_COMPACT.Rmd" "$DEST/docs/"

# QC logs
copy_if_exists "$PROJECT/logs/final_project_qc_2026-09-01.txt" "$DEST/results/final_summary/"
copy_if_exists "$PROJECT/logs/final_summary_SHA256_2026-09-01.txt" "$DEST/results/final_summary/"

# Optional modular RMarkdown archive
if [ -d "$PROJECT/D_coccus_workflow_modular" ]; then
    mkdir -p "$DEST/docs/workflow_modules"
    find "$PROJECT/D_coccus_workflow_modular" -maxdepth 1 -type f \( -name '*.Rmd' -o -name 'README_WORKFLOW_STRUCTURE.txt' \) -exec cp -p {} "$DEST/docs/workflow_modules/" \;
fi

# Manifest
(
  cd "$DEST"
  find . -type f -not -path './.git/*' -print0 | sort -z | xargs -0 sha256sum > MANIFEST.sha256
)

echo
echo "Staging complete. Review with:"
echo "cd \"$DEST\" && find . -maxdepth 3 -type f | sort"
