#!/usr/bin/env Rscript

# ============================================================
# Comparative target repertoire figure - presentation version
# Kerria lacca vs Dactylopius coccus
# ============================================================

needed <- c("ggplot2", "dplyr", "tidyr", "readr", "stringr")
missing_pkgs <- needed[!vapply(needed, requireNamespace, logical(1), quietly = TRUE)]

if (length(missing_pkgs) > 0) {
  install.packages(missing_pkgs, repos = "https://cloud.r-project.org")
}

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(stringr)
})

project_dir <- path.expand("~/D_coccus_gene_families")

input_file <- file.path(
  project_dir,
  "results",
  "final_summary",
  "K_lacca_vs_D_coccus_target_comparison.tsv"
)

out_dir <- file.path(
  project_dir,
  "results",
  "final_figures"
)

dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

if (!file.exists(input_file)) {
  stop("Input file not found:\n", input_file)
}

comparison <- read_tsv(input_file, show_col_types = FALSE)

required_cols <- c(
  "Target",
  "Kerria_lacca",
  "Dactylopius_coccus"
)

missing_cols <- setdiff(required_cols, names(comparison))

if (length(missing_cols) > 0) {
  stop(
    "Missing expected columns: ",
    paste(missing_cols, collapse = ", ")
  )
}

plot_df <- comparison %>%
  select(
    Target,
    Kerria_lacca,
    Dactylopius_coccus
  ) %>%
  pivot_longer(
    cols = c(
      Kerria_lacca,
      Dactylopius_coccus
    ),
    names_to = "Species",
    values_to = "Original_value"
  ) %>%
  mutate(
    Species = recode(
      Species,
      Kerria_lacca = "K. lacca",
      Dactylopius_coccus = "D. coccus"
    ),

    Copy_number = as.integer(
      str_extract(Original_value, "^\\d+")
    ),

    Status = case_when(
      Target == "TRPA5" &
        Species == "D. coccus" ~
        "Disrupted orthologous locus",

      Target == "Pyrexia" &
        Species == "K. lacca" ~
        "Not confidently assigned",

      str_detect(
        Original_value,
        "^0"
      ) ~
        "Not detected",

      TRUE ~
        "Detected / apparently intact"
    ),

    Display_label = as.character(Copy_number)
  )

target_order <- c(
  "Painless",
  "NompC",
  "TRPM",
  "Piezo",
  "Pkd2",
  "ppk/rpk/ppk26",
  "TRPA1",
  "TRPA5",
  "Pyrexia",
  "Straightjacket"
)

plot_df <- plot_df %>%
  mutate(
    Target = factor(
      Target,
      levels = rev(target_order)
    ),
    Species = factor(
      Species,
      levels = c(
        "K. lacca",
        "D. coccus"
      )
    ),
    Status = factor(
      Status,
      levels = c(
        "Detected / apparently intact",
        "Disrupted orthologous locus",
        "Not detected",
        "Not confidently assigned"
      )
    )
  )

caption_text <- paste0(
  "D. coccus TRPA5: an orthologous locus was detected, but an intact coding sequence was not confirmed. ",
  "K. lacca Pyrexia: no copy was confidently assigned in the original survey; ",
  "direct Pyrexia copy-number comparison remains provisional."
)

p <- ggplot(
  plot_df,
  aes(
    x = Species,
    y = Target,
    fill = Status
  )
) +
  geom_tile(
    width = 0.82,
    height = 0.86,
    linewidth = 0.7
  ) +
  geom_text(
    aes(label = Display_label),
    size = 6.2,
    fontface = "bold"
  ) +
  scale_fill_manual(
    values = c(
      "Detected / apparently intact" = "#D9EAD3",
      "Disrupted orthologous locus" = "#F4CCCC",
      "Not detected" = "#E7E6E6",
      "Not confidently assigned" = "#FFF2CC"
    ),
    drop = FALSE
  ) +
  scale_x_discrete(
    labels = c(
      "K. lacca" = expression(italic("K. lacca")),
      "D. coccus" = expression(italic("D. coccus"))
    ),
    position = "top",
    expand = expansion(add = 0.55)
  ) +
  labs(
    title = "Nociception-associated target repertoire",
    subtitle = expression(
      italic("Kerria lacca") ~ "vs" ~ italic("Dactylopius coccus")
    ),
    x = NULL,
    y = NULL,
    fill = "Interpretation",
    caption = str_wrap(caption_text, width = 115)
  ) +
  guides(
    fill = guide_legend(
      nrow = 2,
      byrow = TRUE,
      title.position = "top"
    )
  ) +
  theme_minimal(
    base_size = 13
  ) +
  theme(
    panel.grid = element_blank(),

    axis.text.x = element_text(
      size = 13,
      face = "bold",
      margin = margin(b = 10)
    ),

    axis.text.y = element_text(
      size = 12,
      face = "bold"
    ),

    plot.title = element_text(
      size = 19,
      face = "bold",
      hjust = 0.5,
      margin = margin(b = 5)
    ),

    plot.subtitle = element_text(
      size = 15,
      hjust = 0.5,
      margin = margin(b = 16)
    ),

    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.title = element_text(
      face = "bold",
      size = 11
    ),
    legend.text = element_text(
      size = 10
    ),
    legend.spacing.x = unit(0.35, "cm"),
    legend.box = "vertical",

    plot.caption = element_text(
      size = 9.5,
      hjust = 0,
      lineheight = 1.15,
      margin = margin(t = 14)
    ),

    plot.margin = margin(
      18, 35, 18, 35
    )
  )

png_file <- file.path(
  out_dir,
  "Klacca_vs_Dcoccus_target_repertoire_FINAL.png"
)

pdf_file <- file.path(
  out_dir,
  "Klacca_vs_Dcoccus_target_repertoire_FINAL.pdf"
)

ggsave(
  filename = png_file,
  plot = p,
  width = 10.5,
  height = 8.5,
  units = "in",
  dpi = 300,
  bg = "white"
)

ggsave(
  filename = pdf_file,
  plot = p,
  width = 10.5,
  height = 8.5,
  units = "in",
  bg = "white"
)

message("")
message("DONE")
message("PNG: ", png_file)
message("PDF: ", pdf_file)
message("Rows plotted: ", nrow(plot_df))
message("Expected: 20 = 10 targets x 2 species")
