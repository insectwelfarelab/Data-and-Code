from pathlib import Path
import csv

project = Path.home() / "D_coccus_gene_families"
outdir = project / "results/final_summary"
outdir.mkdir(parents=True, exist_ok=True)

rows = [
    ["Painless", "1", "1", "1 apparently intact locus", "same detected copy number"],
    ["NompC", "1", "1", "1 apparently intact locus", "same detected copy number"],
    ["TRPM", "1", "1", "1 apparently intact locus", "same detected copy number"],
    ["Piezo", "2", "2", "1 canonical Piezo + 1 divergent Piezo-like paralog", "same family-level detected copy number"],
    ["Pkd2", "0 detected", "0 detected", "not detected after sensitive genome-level TBLASTN", "not detected in either species"],
    ["ppk/rpk/ppk26", "2", "2", "2 apparently intact ppk/41X6F-like target-related loci", "same target-related detected copy number; exact one-to-one orthology unresolved"],
    ["TRPA1", "1", "1", "1 apparently intact locus", "same detected copy number"],
    ["TRPA5", "0 detected", "1 qualified", "1 orthologous locus detected but disrupted; intact coding sequence not confirmed", "D. coccus has a disrupted orthologous locus"],
    ["Pyrexia", "0 confidently assigned", "3", "3 apparently intact Pyrexia-lineage loci", "D. coccus shows a Pyrexia-lineage expansion relative to the conservative K. lacca classification"],
    ["Straightjacket", "1", "1", "1 apparently intact Straightjacket-like locus; additional stolid-like paralog excluded", "same Straightjacket target count"],
]

outfile = outdir / "K_lacca_vs_D_coccus_target_comparison.tsv"

with outfile.open("w", newline="") as fh:
    writer = csv.writer(fh, delimiter="\t")
    writer.writerow([
        "Target",
        "Kerria_lacca",
        "Dactylopius_coccus",
        "Dcoccus_status",
        "Comparison",
    ])
    writer.writerows(rows)

print(f"Wrote {len(rows)} target rows:")
print(outfile)
